import os
import time
import json
import requests
import telepot
from telepot.loop import MessageLoop

# Ganti dengan Token Bot Telegram & Chat ID Anda
TOKEN = "7250228481:AAG-C6TQMlIH8g0MZgEocnyNuaKRUaWzpYE"
CHAT_ID = "6450551010"

bot = telepot.Bot(TOKEN)

# Kirim notifikasi saat HP dinyalakan
def send_startup_message():
    message = "🔒 HP Anda telah dinyalakan/reboot!"
    bot.sendMessage(CHAT_ID, message)

# Kirim lokasi HP saat diminta
def send_location():
    try:
        loc_data = os.popen("termux-location").read()
        loc_json = json.loads(loc_data)
        latitude = loc_json["latitude"]
        longitude = loc_json["longitude"]
        bot.sendLocation(CHAT_ID, latitude, longitude)
        bot.sendMessage(CHAT_ID, "📍 Ini lokasi HP Anda!")
    except Exception as e:
        bot.sendMessage(CHAT_ID, f"⚠️ Gagal mendapatkan lokasi: {str(e)}")

# Kirim foto jika ada upaya masuk yang gagal
def send_intruder_photo():
    try:
        os.system("termux-camera-photo intruder.jpg")
        bot.sendPhoto(CHAT_ID, photo=open("intruder.jpg", "rb"))
        bot.sendMessage(CHAT_ID, "🚨 Foto penyusup telah dikirim!")
    except Exception as e:
        bot.sendMessage(CHAT_ID, f"⚠️ Gagal mengambil foto: {str(e)}")

# Cek apakah ada kesalahan masuk
def monitor_failed_logins():
    while True:
        logs = os.popen("logcat -d | grep 'Password failed'").read()
        if logs:
            bot.sendMessage(CHAT_ID, "🚨 Ada percobaan masuk yang gagal!")
            send_intruder_photo()
        time.sleep(10)

# Tangani pesan dari bot
def handle_message(msg):
    chat_id = msg['chat']['id']
    command = msg['text'].lower()

    if command == "/lokasi":
        send_location()
    elif command == "/foto":
        send_intruder_photo()
    else:
        bot.sendMessage(chat_id, "❌ Perintah tidak dikenali!")

# Jalankan fungsi utama
if __name__ == "__main__":
    send_startup_message()
    
    # Jalankan listener untuk menerima perintah Telegram
    MessageLoop(bot, handle_message).run_as_thread()
    
    # Pantau percobaan masuk yang gagal
    monitor_failed_logins()
